import config from './base.js';

config.output.file = 'dist/esri-leaflet-geocoder-debug.js';
config.output.sourcemap = true;

export default config;
